# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 21:23:20 2024

@author: Sumel Rattan
"""
import cv2
import numpy as np
import random
from collections import deque
import math
import heapq, time

# Game settings 
screen_width = 800  # px
cell_size = 20     # px
grid_cells = screen_width // cell_size  # How many cells fit on screen

# Colors (BGR because OpenCV is quirky like that 🙄)
black = (0, 0, 0)
white = (255, 255, 255)
apple_red = (0, 0, 255)      # Food color
snake_head = (0, 255, 255)   # Yellow
snake_body = (0, 200, 0)     # Slightly darker green than pure green

class SearchMetrics:
    def __init__(self):
        self.reset()
    
    def reset(self):
        self.nodes_expanded = 0
        self.path_length = 0
        self.search_depth = 0

class SnakeGame:
    def __init__(self, ai_controlled=False, search_algorithm='greedy'):
        # Create the game window
        self.canvas = np.zeros((screen_width, screen_width, 3), dtype=np.uint8)
        self.ai_controlled = ai_controlled
        self.search_algorithm = search_algorithm
        self.search_metrics = SearchMetrics()
        self.display_startup_screen()

        self.start_fresh_game()
        self.difficulty = 1  # Starting difficulty
        self.frame_delay = 100  # ms between frames (lower = faster)

    def display_startup_screen(self):
        """
        Display a startup screen with game controls and instructions
        """
        # Create a startup canvas
        startup_canvas = np.zeros((screen_width, screen_width, 3), dtype=np.uint8)
        startup_canvas.fill(255)  # White background

        # Title
        cv2.putText(startup_canvas, "Snake AI Search Algorithms", 
                    (100, 100), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, black, 2)

        # Controls
        controls = [
            "Game Controls:",
            "T: Toggle AI Mode",
            "N: Cycle Search Algorithms",
            "R: Restart Game (when dead)",
            "Q: Quit Game",
            "",
            "Search Algorithms:",
            "* Greedy Best-First Search",
            "* A* Search",
            "* Uniform Cost Search",
            "",
            "Metrics Displayed:",
            "* Nodes Expanded",
            "* Path Length"
        ]

        # Render controls
        for i, text in enumerate(controls):
            cv2.putText(startup_canvas, text, 
                        (200, 150 + i*30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, black, 1)

        # Press any key to start
        cv2.putText(startup_canvas, "Press any key to start", 
                    (200, 700), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        # Show the startup screen
        cv2.imshow('Snake! Search Algorithms', startup_canvas)
        cv2.waitKey(0)  # Wait for any key press
        cv2.destroyAllWindows()  # Close the startup screen

    def start_fresh_game(self):
        # Start with a tiny snake in the middle of the screen
        start_x, start_y = grid_cells // 2, grid_cells // 2
        self.snake = [(start_x, start_y)]
        self.heading = [1, 0]  # Start moving right
        
        self.place_new_food()
        self.points = 0
        self.is_dead = False
    
    def place_new_food(self):
        # Keep trying random spots until we find one not occupied by the snake
        while True:
            food_x = random.randint(0, grid_cells - 1)
            food_y = random.randint(0, grid_cells - 1)
            food_pos = (food_x, food_y)
            
            if food_pos not in self.snake:
                self.food = food_pos
                break

    def get_valid_moves(self):
        """Return list of valid moves from current position"""
        valid_moves = []
        current_head = self.snake[0]
        
        # All possible moves
        possible_moves = [
            ([1, 0], (current_head[0] + 1) % grid_cells, current_head[1]),  # Right
            ([-1, 0], (current_head[0] - 1) % grid_cells, current_head[1]),  # Left
            ([0, 1], current_head[0], (current_head[1] + 1) % grid_cells),   # Down
            ([0, -1], current_head[0], (current_head[1] - 1) % grid_cells)   # Up
        ]
        
        # Can't do 180-degree turns
        opposite_heading = [-self.heading[0], -self.heading[1]]
        
        for move, x, y in possible_moves:
            if move != opposite_heading and (x, y) not in self.snake[:-1]:
                valid_moves.append(move)
        
        return valid_moves

    def heuristic(self, a, b):
        """Manhattan distance heuristic"""
        return abs(a[0] - b[0]) + abs(a[1] - b[1])    

    def get_neighbors(self, node, grid):
        """Get valid neighboring cells"""
        neighbors = []
        possible_moves = [
            (1, 0),   # Right
            (-1, 0),  # Left
            (0, 1),   # Down
            (0, -1)   # Up
        ]
        
        for dx, dy in possible_moves:
            new_x = (node[0] + dx) % grid_cells
            new_y = (node[1] + dy) % grid_cells
            new_node = (new_x, new_y)
            
            # Ensure new position is not in snake body
            if new_node not in self.snake[:-1]:
                neighbors.append(new_node)
        
        return neighbors

    def a_star_search(self, start, goal):
        """A* Search Algorithm"""
        start_time = time.time()
        self.search_metrics.reset()
        
        frontier = []
        heapq.heappush(frontier, (0, start))
        came_from = {start: None}
        cost_so_far = {start: 0}
        
        while frontier:
            current_cost, current = heapq.heappop(frontier)
            self.search_metrics.nodes_expanded += 1
            
            if current == goal:
                break
            
            for next in self.get_neighbors(current, grid_cells):
                new_cost = cost_so_far[current] + 1
                
                if next not in cost_so_far or new_cost < cost_so_far[next]:
                    cost_so_far[next] = new_cost
                    priority = new_cost + self.heuristic(goal, next)
                    heapq.heappush(frontier, (priority, next))
                    came_from[next] = current
        
        # Reconstruct path
        path = []
        current = goal
        while current != start:
            path.append(current)
            current = came_from.get(current)
        path.append(start)
        path.reverse()
        
        # Update metrics
        self.search_metrics.path_length = len(path)
        self.search_metrics.search_depth = len(path)
        
        return path

    def greedy_best_first_search(self, start, goal):
        """Greedy Best-First Search Algorithm"""
        start_time = time.time()
        self.search_metrics.reset()
        
        frontier = []
        heapq.heappush(frontier, (self.heuristic(start, goal), start))
        came_from = {start: None}
        
        while frontier:
            _, current = heapq.heappop(frontier)
            self.search_metrics.nodes_expanded += 1
            
            if current == goal:
                break
            
            for next in self.get_neighbors(current, grid_cells):
                if next not in came_from:
                    priority = self.heuristic(next, goal)
                    heapq.heappush(frontier, (priority, next))
                    came_from[next] = current
        
        # Reconstruct path
        path = []
        current = goal
        while current != start:
            path.append(current)
            current = came_from.get(current)
        path.append(start)
        path.reverse()
        
        # Update metrics
        self.search_metrics.path_length = len(path)
        self.search_metrics.search_depth = len(path)
        
        return path

    def uniform_cost_search(self, start, goal):
        """Uniform Cost Search Algorithm"""
        start_time = time.time()
        self.search_metrics.reset()
        
        frontier = []
        heapq.heappush(frontier, (0, start))
        came_from = {start: None}
        cost_so_far = {start: 0}
        
        while frontier:
            current_cost, current = heapq.heappop(frontier)
            self.search_metrics.nodes_expanded += 1
            
            if current == goal:
                break
            
            for next in self.get_neighbors(current, grid_cells):
                new_cost = cost_so_far[current] + 1
                
                if next not in cost_so_far or new_cost < cost_so_far[next]:
                    cost_so_far[next] = new_cost
                    heapq.heappush(frontier, (new_cost, next))
                    came_from[next] = current
        
        # Reconstruct path
        path = []
        current = goal
        while current != start:
            path.append(current)
            current = came_from.get(current)
        path.append(start)
        path.reverse()
        
        # Update metrics
        self.search_metrics.path_length = len(path)
        self.search_metrics.search_depth = len(path)
        
        return path

    def manhattan_distance(self, pos1, pos2):
        """Calculate Manhattan distance between two points"""
        return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

    def get_best_move(self):
        """Implement search algorithm selection"""
        current_head = self.snake[0]
        
        # Select search algorithm based on the set algorithm
        if self.search_algorithm == 'a_star':
            path = self.a_star_search(current_head, self.food)
        elif self.search_algorithm == 'greedy':
            path = self.greedy_best_first_search(current_head, self.food)
        elif self.search_algorithm == 'uniform_cost':
            path = self.uniform_cost_search(current_head, self.food)
        else:
            return self.heading  # Default to current heading
        
        # If path exists, choose the next move
        if len(path) > 1:
            next_pos = path[1]
            move = [
                next_pos[0] - current_head[0],
                next_pos[1] - current_head[1]
            ]
            return move
        
        return self.heading
    
    def update_game_state(self):
        if self.is_dead:
            return

        # If AI-controlled, get the best move
        if self.ai_controlled:
            self.heading = self.get_best_move()

        # Figure out where the head will be
        old_head = self.snake[0]
        new_head = (
            (old_head[0] + self.heading[0]) % grid_cells,
            (old_head[1] + self.heading[1]) % grid_cells
        )
        
        # Oops, ate ourselves!
        if new_head in self.snake:
            self.is_dead = True
            return
            
        self.snake.insert(0, new_head)
        
        # Nom nom nom
        if new_head == self.food:
            self.points += 1
            self.place_new_food()
            
            # Level up every 5 points
            if self.points % 5 == 0:
                self.difficulty = min(5, self.difficulty + 1)
                self.frame_delay = max(50, 100 - (self.difficulty - 1) * 10)
        else:
            # No food? Then we don't grow
            self.snake.pop()

    def draw_cell(self, pos, color):
        x, y = pos
        top_left = (x * cell_size, y * cell_size)
        bottom_right = ((x + 1) * cell_size - 2, (y + 1) * cell_size - 2)
        cv2.rectangle(self.canvas, top_left, bottom_right, color, -1)

    def draw_snake_face(self, head_pos):
        x, y = head_pos
        # Draw the base of the head
        top_left = (x * cell_size, y * cell_size)
        bottom_right = ((x + 1) * cell_size - 2, (y + 1) * cell_size - 2)
        cv2.rectangle(self.canvas, top_left, bottom_right, snake_head, -1)
        
        # Add some personality with eyes and mouth!
        eye_size = 4
        
        # Position face features based on which way we're going
        if self.heading == [1, 0]:  # Right
            left_eye = (x * cell_size + cell_size - 8, y * cell_size + 5)
            right_eye = (x * cell_size + cell_size - 8, y * cell_size + cell_size - 8)
            mouth_start = (x * cell_size + cell_size - 2, y * cell_size + cell_size//2)
            mouth_end = (x * cell_size + cell_size + 4, y * cell_size + cell_size//2)
        elif self.heading == [-1, 0]:  # Left
            left_eye = (x * cell_size + 8, y * cell_size + 5)
            right_eye = (x * cell_size + 8, y * cell_size + cell_size - 8)
            mouth_start = (x * cell_size + 2, y * cell_size + cell_size//2)
            mouth_end = (x * cell_size - 4, y * cell_size + cell_size//2)
        elif self.heading == [0, -1]:  # Up
            left_eye = (x * cell_size + 5, y * cell_size + 8)
            right_eye = (x * cell_size + cell_size - 8, y * cell_size + 8)
            mouth_start = (x * cell_size + cell_size//2, y * cell_size + 2)
            mouth_end = (x * cell_size + cell_size//2, y * cell_size - 4)
        else:  # Down
            left_eye = (x * cell_size + 5, y * cell_size + cell_size - 8)
            right_eye = (x * cell_size + cell_size - 8, y * cell_size + cell_size - 8)
            mouth_start = (x * cell_size + cell_size//2, y * cell_size + cell_size - 2)
            mouth_end = (x * cell_size + cell_size//2, y * cell_size + cell_size + 4)
        
        # Draw the face
        cv2.circle(self.canvas, left_eye, eye_size, black, -1)
        cv2.circle(self.canvas, right_eye, eye_size, black, -1)
        cv2.line(self.canvas, mouth_start, mouth_end, black, 2)

    def draw_game(self):
        # Start with a clean slate
        self.canvas.fill(0)
        
        # Draw the snake's body first (so head draws on top)
        for body_part in self.snake[1:]:
            self.draw_cell(body_part, snake_body)
        
        # Draw the head with a face!
        self.draw_snake_face(self.snake[0])
        
        # Draw the food
        self.draw_cell(self.food, apple_red)
        
        # Show the score and level
        score_text = f'Points: {self.points}  Level: {self.difficulty}'
        mode_text = 'AI Mode' if self.ai_controlled else 'Player Mode'
        cv2.putText(self.canvas, f'{score_text} - {mode_text}', (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, white, 2)
        
        # Display search metrics
        metric_text = (
            f"Algorithm: {self.search_algorithm.replace('_', ' ').title()} | "
            f"Nodes: {self.search_metrics.nodes_expanded} | "
            f"Path Length: {self.search_metrics.path_length} "
        )

        cv2.putText(self.canvas, metric_text, (10, 70), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, white, 2)

        # Game over message
        if self.is_dead:
            message = 'Game Over! Press R to try again'
            text_size = cv2.getTextSize(message, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
            text_x = (screen_width - text_size[0]) // 2
            text_y = screen_width // 2
            cv2.putText(self.canvas, message, (text_x, text_y),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, white, 2)
        
        return self.canvas

    def play(self):
        available_algorithms = ['greedy', 'a_star', 'uniform_cost']
        current_algo_index = 0
        
        while True:
            current_frame = self.draw_game()
            cv2.imshow('Snake! Search Algorithms', current_frame)
            
            key = cv2.waitKey(self.frame_delay)
            
            # Q to quit
            if key == ord('q'):
                break
            # R to restart if we're dead
            elif key == ord('r') and self.is_dead:
                self.start_fresh_game()
            # T to toggle AI control
            elif key == ord('t'):
                self.ai_controlled = not self.ai_controlled
            # N to cycle through search algorithms
            elif key == ord('n'):
                current_algo_index = (current_algo_index + 1) % len(available_algorithms)
                self.search_algorithm = available_algorithms[current_algo_index]
            # Movement keys (but don't allow 180-degree turns) - only if not AI controlled
            elif not self.is_dead and not self.ai_controlled:
                if key == ord('w') and self.heading != [0, 1]:
                    self.heading = [0, -1]  # Up
                elif key == ord('s') and self.heading != [0, -1]:
                    self.heading = [0, 1]   # Down
                elif key == ord('a') and self.heading != [1, 0]:
                    self.heading = [-1, 0]  # Left
                elif key == ord('d') and self.heading != [-1, 0]:
                    self.heading = [1, 0]   # Right
            
            # Update game state if we're still alive
            if not self.is_dead:
                self.update_game_state()
        
        cv2.destroyAllWindows()


# Let's play!
if __name__ == '__main__':
    game = SnakeGame(ai_controlled=False)  # Start in player mode
    game.play()