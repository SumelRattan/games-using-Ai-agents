import random
import time
import heapq
import copy
import psutil
import sys

from rubiksCube import RubiksCube2x2

class RubiksCube2x2Solver(RubiksCube2x2):
    def __init__(self):
        super().__init__()
        self.rotation_methods = [
            self.rotate_front_clockwise,
            self.rotate_front_counterclockwise,
            self.rotate_back_clockwise,
            self.rotate_back_counterclockwise,
            self.rotate_right_clockwise,
            self.rotate_right_counterclockwise,
            self.rotate_left_clockwise,
            self.rotate_left_counterclockwise,
            self.rotate_up_clockwise,
            self.rotate_up_counterclockwise,
            self.rotate_down_clockwise,
            self.rotate_down_counterclockwise
        ]
    
    def shuffle(self, moves=20):
        """Randomly shuffle the cube."""
        for _ in range(moves):
            random.choice(self.rotation_methods)()
        return self
    
    def get_heuristic(self):
        """Calculate heuristic value based on color mismatches."""
        mismatches = 0
        for face in self.faces.values():
            color = face[0][0]
            mismatches += 4 - sum(1 for row in face for cell in row if cell == color)
        return mismatches
    
    def state_hash(self):
        """Create a hashable representation of the cube state."""
        return tuple(tuple(tuple(row) for row in face) for face in self.faces.values())
    
    def clone(self):
        """Create a deep copy of the current cube state."""
        new_cube = RubiksCube2x2Solver()
        new_cube.faces = copy.deepcopy(self.faces)
        return new_cube
    
    def a_star_solve(self, max_iterations=1000):
        """Solve the cube using A* search algorithm."""
        start_time = time.time()
        memory_start = psutil.Process().memory_info().rss / (1024 * 1024)
    
        start_state = self.state_hash()
        heap = [(0, 0, self.state_hash(), self, [])]
        visited = set([start_state])
    
        while heap:
            f_score, cost, state_hash, current_cube, path = heapq.heappop(heap)
        
            if current_cube.is_solved():
                end_time = time.time()
                memory_end = psutil.Process().memory_info().rss / (1024 * 1024)
                return {
                    'solution': path,
                    'time': end_time - start_time,
                    'moves': len(path),
                    'memory_used': memory_end - memory_start
                }
        
            if len(path) >= max_iterations:
                continue
        
            for method in current_cube.rotation_methods:
                new_cube = current_cube.clone()
                method()
            
                new_state = new_cube.state_hash()
                if new_state not in visited:
                    visited.add(new_state)
                
                    # Heuristic calculation
                    h_score = new_cube.get_heuristic()
                    new_f_score = len(path) + 1 + h_score
                    new_path = path + [method.__name__]
                
                    # Use a unique identifier (state_hash) to break ties
                    heapq.heappush(heap, (new_f_score, len(path) + 1, new_state, new_cube, new_path))
    
        return None

    def uniform_cost_solve(self, max_iterations=1000):
        start_time = time.time()
        memory_start = psutil.Process().memory_info().rss / (1024 * 1024)
    
        start_state = self.state_hash()
        heap = [(0, start_state, self, [])]
        visited = set([start_state])
    
        while heap:
            cost, state_hash, current_cube, path = heapq.heappop(heap)
        
            if current_cube.is_solved():
                end_time = time.time()
                memory_end = psutil.Process().memory_info().rss / (1024 * 1024)
                return {
                    'solution': path,
                    'time': end_time - start_time,
                    'moves': len(path),
                    'memory_used': memory_end - memory_start
                }
        
            if len(path) >= max_iterations:
                continue
        
            for method in current_cube.rotation_methods:
                new_cube = current_cube.clone()
                method()
            
                new_state = new_cube.state_hash()
                if new_state not in visited:
                    visited.add(new_state)
                
                    heapq.heappush(heap, (cost + 1, new_state, new_cube, path + [method.__name__]))
    
        return None

def play_rubiks_cube_solver():
    """Enhanced Rubik's Cube game with solving algorithms."""
    cube = RubiksCube2x2Solver()
    
    print("Welcome to 2x2 Rubik's Cube Solver!")
    print("Available commands:")
    print("- 'print': Show current cube state")
    print("Rotation Commands:")
    print("- 'fc': Front Clockwise")
    print("- 'fcr': Front Counterclockwise")
    print("- 'bc': Back Clockwise")
    print("- 'bcr': Back Counterclockwise")
    print("- 'rc': Right Clockwise")
    print("- 'rcr': Right Counterclockwise")
    print("- 'lc': Left Clockwise")
    print("- 'lcr': Left Counterclockwise")
    print("- 'uc': Up Clockwise")
    print("- 'ucr': Up Counterclockwise")
    print("- 'dc': Down Clockwise")
    print("- 'dcr': Down Counterclockwise")
    print("Solving Commands:")
    print("- 'shuffle [n]': Shuffle cube (optional number of moves)")
    print("- 'astar': Solve using A* Search")
    print("- 'uniform': Solve using Uniform Cost Search")
    print("- 'check': Check if cube is solved")
    print("- 'quit': Exit the game")
    
    while True:
        cube.print_cube()
        command = input("\nEnter a command: ").strip().lower()
        
        # Rotation commands
        if command == 'fc':
            cube.rotate_front_clockwise()
        elif command == 'fcr':
            cube.rotate_front_counterclockwise()
        elif command == 'bc':
            cube.rotate_back_clockwise()
        elif command == 'bcr':
            cube.rotate_back_counterclockwise()
        elif command == 'rc':
            cube.rotate_right_clockwise()
        elif command == 'rcr':
            cube.rotate_right_counterclockwise()
        elif command == 'lc':
            cube.rotate_left_clockwise()
        elif command == 'lcr':
            cube.rotate_left_counterclockwise()
        elif command == 'uc':
            cube.rotate_up_clockwise()
        elif command == 'ucr':
            cube.rotate_up_counterclockwise()
        elif command == 'dc':
            cube.rotate_down_clockwise()
        elif command == 'dcr':
            cube.rotate_down_counterclockwise()
        
        # Solving commands
        elif command.startswith('shuffle'):
            try:
                moves = int(command.split()[1]) if len(command.split()) > 1 else 20
                cube.shuffle(moves)
                print(f"Cube shuffled with {moves} random moves.")
            except ValueError:
                print("Invalid shuffle command. Use 'shuffle [number of moves]'.")
        
        elif command == 'astar':
            print("Solving using A* Search...")
            result = cube.a_star_solve()
            if result:
                print("\nA* Search Solution:")
                print(f"Solution Moves: {result['solution']}")
                print(f"Time Taken: {result['time']:.4f} seconds")
                print(f"Total Moves: {result['moves']}")
                print(f"Memory Used: {result['memory_used']:.2f} MB")
            else:
                print("No solution found.")
        

        elif command == 'uniform':
            print("Solving using Uniform Cost Search...")
            result = cube.uniform_cost_solve()
            if result:
                print("\nUniform Cost Search Solution:")
                print(f"Solution Moves: {result['solution']}")
                print(f"Time Taken: {result['time']:.4f} seconds")
                print(f"Total Moves: {result['moves']}")
                print(f"Memory Used: {result['memory_used']:.2f} MB")
            else:
                print("No solution found.")
        
        # Utility commands
        elif command == 'print':
            cube.print_cube()
        elif command == 'check':
            if cube.is_solved():
                print("Congratulations! The cube is solved!")
            else:
                print("The cube is not yet solved. Keep trying!")
        elif command == 'quit':
            print("Thanks for playing!")
            break
        
        # Invalid command handling
        else:
            print("Invalid command. Please try again.")

# Main execution
if __name__ == "__main__":
    play_rubiks_cube_solver()