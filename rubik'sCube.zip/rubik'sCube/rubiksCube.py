import random

class RubiksCube2x2:
    def __init__(self, shuffle_moves=20):
        """
        Initialize the cube with standard colors and optionally shuffle it.
        
        Args:
            shuffle_moves (int): Number of random moves to perform during initialization.
                                 Default is 20 moves.
        """
        # Initialize the cube with standard colors
        # Each face is represented by a 2x2 matrix
        # Colors: W (White), Y (Yellow), R (Red), O (Orange), B (Blue), G (Green)
        self.faces = {
            'front': [['R', 'R'], 
                      ['R', 'R']],
            'back': [['O', 'O'], 
                     ['O', 'O']],
            'up': [['W', 'W'], 
                   ['W', 'W']],
            'down': [['Y', 'Y'], 
                     ['Y', 'Y']],
            'left': [['B', 'B'], 
                     ['B', 'B']],
            'right': [['G', 'G'], 
                      ['G', 'G']]
        }
        
        # List of all possible rotation methods
        rotation_methods = [
            self.rotate_front_clockwise,
            self.rotate_front_counterclockwise,
            self.rotate_back_clockwise,
            self.rotate_back_counterclockwise,
            self.rotate_right_clockwise,
            self.rotate_right_counterclockwise,
            self.rotate_left_clockwise,
            self.rotate_left_counterclockwise,
            self.rotate_up_clockwise,
            self.rotate_up_counterclockwise,
            self.rotate_down_clockwise,
            self.rotate_down_counterclockwise
        ]
        
        # # Randomly shuffle the cube
        # for _ in range(shuffle_moves):
        #     # Randomly select and execute a rotation method
        #     random.choice(rotation_methods)()
    
    def print_cube(self):
        """Print the current state of the cube."""
        print("Cube Current State:")
        for face_name, face in self.faces.items():
            print(f"\n{face_name.upper()} Face:")
            for row in face:
                print(' '.join(row))
    
    def rotate_face_clockwise(self, face):
        """Rotate a given face clockwise."""
        self.faces[face] = [
            [self.faces[face][1][0], self.faces[face][0][0]],
            [self.faces[face][1][1], self.faces[face][0][1]]
        ]
    
    def rotate_face_counterclockwise(self, face):
        """Rotate a given face counterclockwise."""
        self.faces[face] = [
            [self.faces[face][0][1], self.faces[face][1][1]],
            [self.faces[face][0][0], self.faces[face][1][0]]
        ]
    
    def rotate_front_clockwise(self):
        """Perform a front face clockwise rotation."""
        self.rotate_face_clockwise('front')
        
        temp_up_bottom = self.faces['up'][1]
        temp_right_left = [self.faces['right'][0][0], self.faces['right'][1][0]]
        temp_down_top = self.faces['down'][0]
        temp_left_right = [self.faces['left'][0][1], self.faces['left'][1][1]]
        
        self.faces['up'][1] = [temp_left_right[1], temp_left_right[0]]
        self.faces['right'][0][0] = temp_down_top[0]
        self.faces['right'][1][0] = temp_down_top[1]
        self.faces['down'][0] = [temp_right_left[1], temp_right_left[0]]
        self.faces['left'][0][1] = temp_up_bottom[0]
        self.faces['left'][1][1] = temp_up_bottom[1]
    
    def rotate_front_counterclockwise(self):
        """Perform a front face counterclockwise rotation."""
        self.rotate_face_counterclockwise('front')
        
        temp_up_bottom = self.faces['up'][1]
        temp_right_left = [self.faces['right'][0][0], self.faces['right'][1][0]]
        temp_down_top = self.faces['down'][0]
        temp_left_right = [self.faces['left'][0][1], self.faces['left'][1][1]]
        
        self.faces['up'][1] = [temp_right_left[0], temp_right_left[1]]
        self.faces['right'][0][0] = temp_up_bottom[1]
        self.faces['right'][1][0] = temp_up_bottom[0]
        self.faces['down'][0] = [temp_left_right[0], temp_left_right[1]]
        self.faces['left'][0][1] = temp_down_top[1]
        self.faces['left'][1][1] = temp_down_top[0]
    
    def rotate_back_clockwise(self):
        """Perform a back face clockwise rotation."""
        self.rotate_face_clockwise('back')
        
        temp_up_top = self.faces['up'][0]
        temp_right_right = [self.faces['right'][0][1], self.faces['right'][1][1]]
        temp_down_bottom = self.faces['down'][1]
        temp_left_left = [self.faces['left'][0][0], self.faces['left'][1][0]]
        
        self.faces['up'][0] = [temp_right_right[1], temp_right_right[0]]
        self.faces['right'][0][1] = temp_down_bottom[0]
        self.faces['right'][1][1] = temp_down_bottom[1]
        self.faces['down'][1] = [temp_left_left[1], temp_left_left[0]]
        self.faces['left'][0][0] = temp_up_top[1]
        self.faces['left'][1][0] = temp_up_top[0]
    
    def rotate_back_counterclockwise(self):
        """Perform a back face counterclockwise rotation."""
        self.rotate_face_counterclockwise('back')
        
        temp_up_top = self.faces['up'][0]
        temp_right_right = [self.faces['right'][0][1], self.faces['right'][1][1]]
        temp_down_bottom = self.faces['down'][1]
        temp_left_left = [self.faces['left'][0][0], self.faces['left'][1][0]]
        
        self.faces['up'][0] = [temp_left_left[0], temp_left_left[1]]
        self.faces['right'][0][1] = temp_up_top[1]
        self.faces['right'][1][1] = temp_up_top[0]
        self.faces['down'][1] = [temp_right_right[0], temp_right_right[1]]
        self.faces['left'][0][0] = temp_down_bottom[1]
        self.faces['left'][1][0] = temp_down_bottom[0]
    
    def rotate_right_clockwise(self):
        """Perform a right face clockwise rotation."""
        self.rotate_face_clockwise('right')
        
        temp_up_right = [self.faces['up'][0][1], self.faces['up'][1][1]]
        temp_front_right = [self.faces['front'][0][1], self.faces['front'][1][1]]
        temp_down_right = [self.faces['down'][0][1], self.faces['down'][1][1]]
        temp_back_left = [self.faces['back'][0][0], self.faces['back'][1][0]]
        
        self.faces['up'][0][1] = temp_front_right[0]
        self.faces['up'][1][1] = temp_front_right[1]
        self.faces['front'][0][1] = temp_down_right[0]
        self.faces['front'][1][1] = temp_down_right[1]
        self.faces['down'][0][1] = temp_back_left[1]
        self.faces['down'][1][1] = temp_back_left[0]
        self.faces['back'][0][0] = temp_up_right[1]
        self.faces['back'][1][0] = temp_up_right[0]
    
    def rotate_right_counterclockwise(self):
        """Perform a right face counterclockwise rotation."""
        self.rotate_face_counterclockwise('right')
        
        temp_up_right = [self.faces['up'][0][1], self.faces['up'][1][1]]
        temp_front_right = [self.faces['front'][0][1], self.faces['front'][1][1]]
        temp_down_right = [self.faces['down'][0][1], self.faces['down'][1][1]]
        temp_back_left = [self.faces['back'][0][0], self.faces['back'][1][0]]
        
        self.faces['up'][0][1] = temp_back_left[0]
        self.faces['up'][1][1] = temp_back_left[1]
        self.faces['front'][0][1] = temp_up_right[0]
        self.faces['front'][1][1] = temp_up_right[1]
        self.faces['down'][0][1] = temp_front_right[0]
        self.faces['down'][1][1] = temp_front_right[1]
        self.faces['back'][0][0] = temp_down_right[1]
        self.faces['back'][1][0] = temp_down_right[0]
    
    def rotate_left_clockwise(self):
        """Perform a left face clockwise rotation."""
        self.rotate_face_clockwise('left')
        
        temp_up_left = [self.faces['up'][0][0], self.faces['up'][1][0]]
        temp_front_left = [self.faces['front'][0][0], self.faces['front'][1][0]]
        temp_down_left = [self.faces['down'][0][0], self.faces['down'][1][0]]
        temp_back_right = [self.faces['back'][0][1], self.faces['back'][1][1]]
        
        self.faces['up'][0][0] = temp_back_right[1]
        self.faces['up'][1][0] = temp_back_right[0]
        self.faces['front'][0][0] = temp_up_left[0]
        self.faces['front'][1][0] = temp_up_left[1]
        self.faces['down'][0][0] = temp_front_left[0]
        self.faces['down'][1][0] = temp_front_left[1]
        self.faces['back'][0][1] = temp_down_left[1]
        self.faces['back'][1][1] = temp_down_left[0]
    
    def rotate_left_counterclockwise(self):
        """Perform a left face counterclockwise rotation."""
        self.rotate_face_counterclockwise('left')
        
        temp_up_left = [self.faces['up'][0][0], self.faces['up'][1][0]]
        temp_front_left = [self.faces['front'][0][0], self.faces['front'][1][0]]
        temp_down_left = [self.faces['down'][0][0], self.faces['down'][1][0]]
        temp_back_right = [self.faces['back'][0][1], self.faces['back'][1][1]]
        
        self.faces['up'][0][0] = temp_front_left[0]
        self.faces['up'][1][0] = temp_front_left[1]
        self.faces['front'][0][0] = temp_down_left[0]
        self.faces['front'][1][0] = temp_down_left[1]
        self.faces['down'][0][0] = temp_back_right[1]
        self.faces['down'][1][0] = temp_back_right[0]
        self.faces['back'][0][1] = temp_up_left[1]
        self.faces['back'][1][1] = temp_up_left[0]
    
    def rotate_up_clockwise(self):
        """Perform an up face clockwise rotation."""
        self.rotate_face_clockwise('up')
        
        temp_front_top = self.faces['front'][0]
        temp_right_top = self.faces['right'][0]
        temp_back_top = self.faces['back'][0]
        temp_left_top = self.faces['left'][0]
        
        self.faces['front'][0] = temp_right_top
        self.faces['right'][0] = temp_back_top
        self.faces['back'][0] = temp_left_top
        self.faces['left'][0] = temp_front_top
    
    def rotate_up_counterclockwise(self):
        """Perform an up face counterclockwise rotation."""
        self.rotate_face_counterclockwise('up')
        
        temp_front_top = self.faces['front'][0]
        temp_right_top = self.faces['right'][0]
        temp_back_top = self.faces['back'][0]
        temp_left_top = self.faces['left'][0]
        
        self.faces['front'][0] = temp_left_top
        self.faces['right'][0] = temp_front_top
        self.faces['back'][0] = temp_right_top
        self.faces['left'][0] = temp_back_top
    
    def rotate_down_clockwise(self):
        """Perform a down face clockwise rotation."""
        self.rotate_face_clockwise('down')
        
        temp_front_bottom = self.faces['front'][1]
        temp_right_bottom = self.faces['right'][1]
        temp_back_bottom = self.faces['back'][1]
        temp_left_bottom = self.faces['left'][1]
        
        self.faces['front'][1] = temp_left_bottom
        self.faces['right'][1] = temp_front_bottom
        self.faces['back'][1] = temp_right_bottom
        self.faces['left'][1] = temp_back_bottom
    
    def rotate_down_counterclockwise(self):
        """Perform a down face counterclockwise rotation."""
        self.rotate_face_counterclockwise('down')
        
        temp_front_bottom = self.faces['front'][1]
        temp_right_bottom = self.faces['right'][1]
        temp_back_bottom = self.faces['back'][1]
        temp_left_bottom = self.faces['left'][1]
        
        self.faces['front'][1] = temp_right_bottom
        self.faces['right'][1] = temp_back_bottom
        self.faces['back'][1] = temp_left_bottom
        self.faces['left'][1] = temp_front_bottom
    
    def is_solved(self):
        """Check if the cube is solved."""
        for face in self.faces.values():
            color = face[0][0]
            if not all(cell == color for row in face for cell in row):
                return False
        return True

def play_rubiks_cube():
    """Interactive Rubik's Cube game for manual solving."""
    cube = RubiksCube2x2()
    
    print("Welcome to 2x2 Rubik's Cube Solver!")
    print("Available commands:")
    print("- 'print': Show current cube state")
    print("Rotation Commands:")
    print("- 'fc': Front Clockwise")
    print("- 'fcr': Front Counterclockwise")
    print("- 'bc': Back Clockwise")
    print("- 'bcr': Back Counterclockwise")
    print("- 'rc': Right Clockwise")
    print("- 'rcr': Right Counterclockwise")
    print("- 'lc': Left Clockwise")
    print("- 'lcr': Left Counterclockwise")
    print("- 'uc': Up Clockwise")
    print("- 'ucr': Up Counterclockwise")
    print("- 'dc': Down Clockwise")
    print("- 'dcr': Down Counterclockwise")
    print("- 'check': Check if cube is solved")
    print("- 'quit': Exit the game")
    
    while True:
        cube.print_cube()
        command = input("\nEnter a command: ").strip().lower()
        
        # Rotation commands
        if command == 'fc':
            cube.rotate_front_clockwise()
        elif command == 'fcr':
            cube.rotate_front_counterclockwise()
        elif command == 'bc':
            cube.rotate_back_clockwise()
        elif command == 'bcr':
            cube.rotate_back_counterclockwise()
        elif command == 'rc':
            cube.rotate_right_clockwise()
        elif command == 'rcr':
            cube.rotate_right_counterclockwise()
        elif command == 'lc':
            cube.rotate_left_clockwise()
        elif command == 'lcr':
            cube.rotate_left_counterclockwise()
        elif command == 'uc':
            cube.rotate_up_clockwise()
        elif command == 'ucr':
            cube.rotate_up_counterclockwise()
        elif command == 'dc':
            cube.rotate_down_clockwise()
        elif command == 'dcr':
            cube.rotate_down_counterclockwise()
        
        # Utility commands
        elif command == 'print':
            cube.print_cube()
        elif command == 'check':
            if cube.is_solved():
                print("Congratulations! The cube is solved!")
            else:
                print("The cube is not yet solved. Keep trying!")
        elif command == 'quit':
            print("Thanks for playing!")
            break
        
        # Invalid command handling
        else:
            print("Invalid command. Please try again.")

# Add this line to actually run the game when the script is executed
if __name__ == "__main__":
    play_rubiks_cube()