import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button
import cv2
from matplotlib import gridspec

class SlidingPuzzle:
    def __init__(self, image_path=None, puzzle_size=3):
        self.puzzle_size = puzzle_size
        self.moves = 0
        
        if image_path:
            try:
                # Loading and resizing image
                img = cv2.imread(image_path)
                if img is None:
                    raise ValueError("Could not load image")
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            except Exception as e:
                print(f"Error loading image: {e}")
                print("Falling back to numbered tiles...")
                img = None
        else:
            img = None
            
        if img is None:
            # Create numbered tiles if no image
            img = np.zeros((300, 300, 3), dtype=np.uint8)
            img.fill(255)  # White background
            for i in range(puzzle_size):
                for j in range(puzzle_size):
                    if i * puzzle_size + j + 1 < puzzle_size * puzzle_size:
                        cv2.putText(img, str(i * puzzle_size + j + 1),
                                  (j * 300 // puzzle_size + 30, i * 300 // puzzle_size + 100),
                                  cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 0), 3)

        # Resize to 300x300
        self.original_img = cv2.resize(img, (300, 300))
        
        # Split image into tiles
        self.tiles = []
        self.tile_size = 300 // puzzle_size
        for i in range(puzzle_size):
            for j in range(puzzle_size):
                tile = self.original_img[i*self.tile_size:(i+1)*self.tile_size,
                                      j*self.tile_size:(j+1)*self.tile_size]
                self.tiles.append(tile)
                
        # Replace last tile with black tile
        self.tiles[-1] = np.zeros((self.tile_size, self.tile_size, 3), dtype=np.uint8)
        
        # Initializing game state
        self.state = list(range(puzzle_size * puzzle_size))
        self.empty_pos = len(self.state) - 1
        self.solved_state = list(range(puzzle_size * puzzle_size))

        # Shuffle tiles at the start
        self.shuffle_initial_state()
        
        # Setup display
        self.fig = plt.figure(figsize=(8, 10))
        gs = gridspec.GridSpec(2, 1, height_ratios=[4, 1])
        self.ax = plt.subplot(gs[0])
        self.button_ax = plt.subplot(gs[1])
        
        # Create shuffle button
        self.shuffle_button = Button(self.button_ax, 'Shuffle')
        self.shuffle_button.on_clicked(self.shuffle)
        
        # Display initial state
        self.display_state()
        self.fig.canvas.mpl_connect('button_press_event', self.on_click)
        self.fig.canvas.mpl_connect('close_event', self.on_close)

    def shuffle_initial_state(self):
        """Shuffle tiles to create a random, solvable initial state."""
        for _ in range(100):  # Perform 100 random moves
            possible_moves = [i for i in range(len(self.state)) if self.is_valid_move(i)]
            if possible_moves:
                self.make_move(np.random.choice(possible_moves))
        self.moves = 0  # Reset move counter
        
    def get_clicked_tile(self, event):
        if event.inaxes != self.ax:
            return None
        
        x, y = event.xdata, event.ydata
        if x is None or y is None:
            return None
            
        col = int(x // self.tile_size)
        row = int(y // self.tile_size)
        
        if 0 <= row < self.puzzle_size and 0 <= col < self.puzzle_size:
            return row * self.puzzle_size + col
        return None
        
    def is_valid_move(self, tile_idx):
        if tile_idx is None:
            return False
            
        # Check if clicked tile is adjacent to empty tile
        empty_row = self.empty_pos // self.puzzle_size
        empty_col = self.empty_pos % self.puzzle_size
        tile_row = tile_idx // self.puzzle_size
        tile_col = tile_idx % self.puzzle_size
        
        return (abs(empty_row - tile_row) == 1 and empty_col == tile_col) or \
               (abs(empty_col - tile_col) == 1 and empty_row == tile_row)
               
    def make_move(self, tile_idx):
        # Swap tiles
        self.state[self.empty_pos], self.state[tile_idx] = \
            self.state[tile_idx], self.state[self.empty_pos]
        self.empty_pos = tile_idx
        self.moves += 1
        
    def is_solved(self):
        return self.state == self.solved_state
        
    def shuffle(self, event):
        # Make random valid moves
        for _ in range(100):
            possible_moves = []
            for i in range(len(self.state)):
                if self.is_valid_move(i):
                    possible_moves.append(i)
            if possible_moves:
                self.make_move(np.random.choice(possible_moves))
        self.moves = 0
        self.display_state()
        
    def display_state(self):
        self.ax.clear()
        img = np.zeros((300, 300, 3), dtype=np.uint8)
        
        for i in range(len(self.state)):
            tile_idx = self.state[i]
            row = i // self.puzzle_size
            col = i % self.puzzle_size
            img[row*self.tile_size:(row+1)*self.tile_size,
                col*self.tile_size:(col+1)*self.tile_size] = self.tiles[tile_idx]
                
        self.ax.imshow(img)
        self.ax.set_title(f'Moves: {self.moves}')
        
        # Check if puzzle is solved
        if self.is_solved():
            self.ax.set_title(f'Solved in {self.moves} moves!')
            
        self.ax.grid(True)
        plt.draw()
        
    def on_click(self, event):
        tile_idx = self.get_clicked_tile(event)
        if self.is_valid_move(tile_idx):
            self.make_move(tile_idx)
            self.display_state()
            
    def on_close(self, event):
        try:
            plt.close(self.fig)
            plt.close('all')
        except Exception as e:
            print(f"Error closing figure: {e}")



def main():
    game = SlidingPuzzle()
    plt.show(block=True)  # blocks execution until the window is closed

if __name__ == "__main__":
    main()