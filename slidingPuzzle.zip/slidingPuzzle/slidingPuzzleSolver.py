import numpy as np
import heapq
import time
import psutil
import tracemalloc
import matplotlib.pyplot as plt
from typing import List, Tuple, Dict

# Import the existing SlidingPuzzle class from your current module
from slidingPuzzle import SlidingPuzzle

class SlidingPuzzleSolver:
    def __init__(self, initial_state, puzzle_size=3):
        """
        Initialize solver with the current puzzle state
        
        Args:
            initial_state (List[int]): The initial state of the puzzle
            puzzle_size (int): Size of the puzzle grid
        """
        self.initial_state = tuple(initial_state)
        self.puzzle_size = puzzle_size
        self.goal_state = tuple(range(puzzle_size * puzzle_size))
        
    def manhattan_distance(self, state: Tuple[int, ...]) -> int:
        """
        Calculate Manhattan distance heuristic
        
        Args:
            state (tuple): Current puzzle state
        
        Returns:
            int: Total Manhattan distance
        """
        distance = 0
        for i, tile in enumerate(state):
            if tile == len(state) - 1:  # Skip empty tile
                continue
            current_row, current_col = i // self.puzzle_size, i % self.puzzle_size
            goal_row, goal_col = tile // self.puzzle_size, tile % self.puzzle_size
            distance += abs(current_row - goal_row) + abs(current_col - goal_col)
        return distance
    
    def get_neighbors(self, state: Tuple[int, ...]) -> List[Tuple[int, ...]]:
        """
        Generate valid neighboring states
        
        Args:
            state (tuple): Current puzzle state
        
        Returns:
            List of possible next states
        """
        neighbors = []
        empty_index = state.index(len(state) - 1)
        empty_row, empty_col = empty_index // self.puzzle_size, empty_index % self.puzzle_size
        
        # Possible moves: up, down, left, right
        moves = [
            (-1, 0),  # Up
            (1, 0),   # Down
            (0, -1),  # Left
            (0, 1)    # Right
        ]
        
        for dx, dy in moves:
            new_row, new_col = empty_row + dx, empty_col + dy
            
            if 0 <= new_row < self.puzzle_size and 0 <= new_col < self.puzzle_size:
                new_index = new_row * self.puzzle_size + new_col
                new_state = list(state)
                new_state[empty_index], new_state[new_index] = new_state[new_index], new_state[empty_index]
                neighbors.append(tuple(new_state))
        
        return neighbors
    
    def a_star_search(self) -> Dict[str, any]:
        """
        A* search algorithm for solving the sliding puzzle
        
        Returns:
            Dictionary with solution metrics
        """
        tracemalloc.start()
        start_time = time.time()
        start_memory = psutil.Process().memory_info().rss / (1024 * 1024)  # MB
        
        initial_node = (0, self.manhattan_distance(self.initial_state), 0, self.initial_state, [])
        frontier = [initial_node]
        explored = set()
        
        while frontier:
            _, heuristic, cost, current_state, path = heapq.heappop(frontier)
            
            if current_state == self.goal_state:
                end_time = time.time()
                end_memory = psutil.Process().memory_info().rss / (1024 * 1024)
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                
                return {
                    'algorithm': 'A*',
                    'solution_length': len(path),
                    'total_time': end_time - start_time,
                    'total_moves': len(path),
                    'memory_used': peak / (1024 * 1024),
                    'path': path
                }
            
            explored.add(current_state)
            
            for neighbor in self.get_neighbors(current_state):
                if neighbor not in explored:
                    g_cost = cost + 1
                    h_cost = self.manhattan_distance(neighbor)
                    f_cost = g_cost + h_cost
                    
                    heapq.heappush(frontier, (f_cost, h_cost, g_cost, neighbor, path + [neighbor]))
        
        return {'algorithm': 'A*', 'solution': None}
    
    def greedy_best_first_search(self) -> Dict[str, any]:
        """
        Greedy Best-First Search algorithm
        
        Returns:
            Dictionary with solution metrics
        """
        tracemalloc.start()
        start_time = time.time()
        start_memory = psutil.Process().memory_info().rss / (1024 * 1024)  # MB
        
        initial_node = (self.manhattan_distance(self.initial_state), self.initial_state, [])
        frontier = [initial_node]
        explored = set()
        
        while frontier:
            _, current_state, path = heapq.heappop(frontier)
            
            if current_state == self.goal_state:
                end_time = time.time()
                end_memory = psutil.Process().memory_info().rss / (1024 * 1024)
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                
                return {
                    'algorithm': 'Greedy Best-First',
                    'solution_length': len(path),
                    'total_time': end_time - start_time,
                    'total_moves': len(path),
                    'memory_used': peak / (1024 * 1024),
                    'path': path
                }
            
            explored.add(current_state)
            
            for neighbor in self.get_neighbors(current_state):
                if neighbor not in explored:
                    h_cost = self.manhattan_distance(neighbor)
                    heapq.heappush(frontier, (h_cost, neighbor, path + [neighbor]))
        
        return {'algorithm': 'Greedy Best-First', 'solution': None}
    
    def uniform_cost_search(self) -> Dict[str, any]:
        """
        Uniform Cost Search algorithm
        
        Returns:
            Dictionary with solution metrics
        """
        tracemalloc.start()
        start_time = time.time()
        start_memory = psutil.Process().memory_info().rss / (1024 * 1024)  # MB
        
        initial_node = (0, self.initial_state, [])
        frontier = [initial_node]
        explored = set()
        
        while frontier:
            cost, current_state, path = heapq.heappop(frontier)
            
            if current_state == self.goal_state:
                end_time = time.time()
                end_memory = psutil.Process().memory_info().rss / (1024 * 1024)
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                
                return {
                    'algorithm': 'Uniform Cost',
                    'solution_length': len(path),
                    'total_time': end_time - start_time,
                    'total_moves': len(path),
                    'memory_used': peak / (1024 * 1024),
                    'path': path
                }
            
            explored.add(current_state)
            
            for neighbor in self.get_neighbors(current_state):
                if neighbor not in explored:
                    new_cost = cost + 1
                    heapq.heappush(frontier, (new_cost, neighbor, path + [neighbor]))
        
        return {'algorithm': 'Uniform Cost', 'solution': None}
    
    def compare_algorithms(self):
        """
        Run and compare solving algorithms
        
        Returns:
            List of algorithm performance metrics
        """
        algorithms = [
            self.a_star_search,
            self.greedy_best_first_search,
            self.uniform_cost_search
        ]
        
        results = []
        for algorithm in algorithms:
            try:
                result = algorithm()
                results.append(result)
                print(f"{result['algorithm']} Search Results:")
                print(f"  Solution Length: {result.get('solution_length', 'N/A')}")
                print(f"  Total Time: {result.get('total_time', 'N/A'):.4f} seconds")
                print(f"  Memory Used: {result.get('memory_used', 'N/A'):.4f} MB\n")
            except Exception as e:
                print(f"Error in {algorithm.__name__}: {e}")
        
        return results

def main():
    # Modify the initialization to match your existing SlidingPuzzle class
    puzzle = SlidingPuzzle()  # Initialize the puzzle
    
    # Create solver with current puzzle state
    solver = SlidingPuzzleSolver(puzzle.state, puzzle.puzzle_size)
    
    # Compare solving algorithms
    results =  solver.compare_algorithms()

    plt.show(block = True)

if __name__ == "__main__":
    main()