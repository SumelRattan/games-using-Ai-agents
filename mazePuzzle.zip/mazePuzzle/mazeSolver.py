import heapq
import time
import numpy as np

class MazeSolver:
    def __init__(self, maze, start, end):
        self.maze = maze
        self.start = start
        self.end = end

    def heuristic(self, current, goal):
        # Manhattan distance
        return abs(current[0] - goal[0]) + abs(current[1] - goal[1])

    def solve(self, algorithm="A*"):
        start_time = time.time()
        
        if algorithm == "A*":
            result = self.a_star()
        elif algorithm == "Greedy":
            result = self.greedy_best_first()
        elif algorithm == "Uniform":
            result = self.uniform_cost_search()
        else:
            raise ValueError("Invalid algorithm specified!")

        elapsed_time = time.time() - start_time
        result["time"] = elapsed_time
        return result

    def a_star(self):
        return self.search(use_heuristic=True, include_cost=True)

    def greedy_best_first(self):
        return self.search(use_heuristic=True, include_cost=False)

    def uniform_cost_search(self):
        return self.search(use_heuristic=False, include_cost=True)

    def search(self, use_heuristic, include_cost):
        open_set = []
        heapq.heappush(open_set, (0, self.start, [self.start], 0))  # (priority, position, path, cost)
        visited = set()

        while open_set:
            priority, current, path, cost = heapq.heappop(open_set)

            if current in visited:
                continue
            visited.add(current)

            if current == self.end:
                return {
                    "path": path,
                    "moves": len(path) - 1,
                    "path_length": len(path),
                    "efficiency": self.heuristic(self.start, self.end) / len(path)
                }

            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                neighbor = (current[0] + dx, current[1] + dy)
                if (0 <= neighbor[0] < self.maze.shape[0] and
                    0 <= neighbor[1] < self.maze.shape[1] and
                    self.maze[neighbor] == 0 and
                    neighbor not in visited):
                    g = cost + 1  # Uniform cost
                    h = self.heuristic(neighbor, self.end) if use_heuristic else 0
                    f = (g if include_cost else 0) + h
                    heapq.heappush(open_set, (f, neighbor, path + [neighbor], g))
        
        return {
            "path": None,
            "moves": 0,
            "path_length": 0,
            "efficiency": 0.0
        }
