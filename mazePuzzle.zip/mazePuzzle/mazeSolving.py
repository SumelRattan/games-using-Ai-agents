import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button
import cv2
from matplotlib import gridspec
import tracemalloc
import psutil
import time
from mazeSolver import MazeSolver

class InteractiveMaze:
    
    def __init__(self, size=30, complexity=0.7):
        self.size = size
        self.complexity = complexity
        self.maze = self.generate_maze()
        self.start = (1, 1)
        self.end = (size-2, size-2)
        self.current_pos = self.start
        self.path_taken = [self.start]
        self.moves = 0
        self.start_time = time.time()
        
        # Setup display
        plt.style.use('dark_background')
        self.fig = plt.figure(figsize=(12, 14))
        gs = gridspec.GridSpec(2, 1, height_ratios=[4, 1])
        self.ax = plt.subplot(gs[0])
        self.button_ax = plt.subplot(gs[1])
        
        # Create buttons
        self.new_maze_button = Button(plt.axes([0.3, 0.05, 0.15, 0.075]), 'New Maze')
        self.reset_button = Button(plt.axes([0.55, 0.05, 0.15, 0.075]), 'Reset')
        
        self.new_maze_button.on_clicked(self.create_new_maze)
        self.reset_button.on_clicked(self.reset_position)
        
        # Connect keyboard events
        self.fig.canvas.mpl_connect('key_press_event', self.on_key_press)
        self.fig.canvas.mpl_connect('close_event', self.on_close)
        
        # Display initial state
        self.display_maze()
        self.print_instructions()

    def print_instructions(self):
        print("\nComplex Maze Challenge:")
        print("- Multiple paths exist!")
        print("- Find the shortest route")
        print("- Green dot: Start position")
        print("- Red dot: End position")
        print("- Blue line: Your path")
        print("- Can you navigate efficiently?")

    def generate_maze(self):
        # Initialize maze with walls
        maze = np.ones((self.size, self.size), dtype=np.uint8)
        
        def recursive_backtracking(x, y):
            maze[y, x] = 0
            
            # Randomize directions
            directions = [(0, 2), (2, 0), (0, -2), (-2, 0)]
            np.random.shuffle(directions)
            
            for dx, dy in directions:
                new_x, new_y = x + dx, y + dy
                
                # Check bounds and if cell is unvisited
                if (0 < new_x < self.size-1 and 
                    0 < new_y < self.size-1 and 
                    maze[new_y, new_x] == 1):
                    
                    # Carve passage
                    maze[y + dy//2, x + dx//2] = 0
                    recursive_backtracking(new_x, new_y)
        
        # Start maze generation from (1,1)
        recursive_backtracking(1, 1)
        
        # Add additional random connections
        num_connections = int(self.size * self.complexity)
        for _ in range(num_connections):
            # Find random open paths
            open_paths = np.argwhere((maze == 0))
            
            if len(open_paths) > 2:
                # Select two random points
                np.random.shuffle(open_paths)
                path1, path2 = open_paths[:2]
                
                # Create a path between these points
                x1, y1 = path1
                x2, y2 = path2
                
                # Bresenham's line algorithm to connect points
                dx = abs(x2 - x1)
                dy = abs(y2 - y1)
                x, y = x1, y1
                sx = 1 if x1 < x2 else -1
                sy = 1 if y1 < y2 else -1
                
                # Carve a path
                if dx > dy:
                    err = dx / 2.0
                    while x != x2:
                        maze[y, x] = 0
                        err -= dy
                        if err < 0:
                            y += sy
                            err += dx
                        x += sx
                else:
                    err = dy / 2.0
                    while y != y2:
                        maze[y, x] = 0
                        err -= dx
                        if err < 0:
                            x += sx
                            err += dy
                        y += sy
                
                # Connect the final point
                maze[y2, x2] = 0
        
        # Add some random open passages
        extra_passages = int(self.size * self.complexity)
        for _ in range(extra_passages):
            x = np.random.randint(1, self.size-1)
            y = np.random.randint(1, self.size-1)
            
            # Thin out walls to create more paths
            if maze[y, x] == 1:
                # Check neighboring cells
                neighbors = [(0,1), (0,-1), (1,0), (-1,0)]
                open_neighbor_count = sum(
                    maze[y+dy, x+dx] == 0 
                    for dx, dy in neighbors 
                    if 0 < y+dy < self.size-1 and 0 < x+dx < self.size-1
                )
                
                # Only open if it doesn't completely isolate the area
                if open_neighbor_count > 0:
                    maze[y, x] = 0
        
        # Ensure start and end points are open
        maze[1, 1] = 0
        maze[self.size-2, self.size-2] = 0
        
        return maze

    def create_new_maze(self, event=None):
        self.maze = self.generate_maze()
        self.reset_position()

    def reset_position(self, event=None):
        self.current_pos = self.start
        self.path_taken = [self.start]
        self.moves = 0
        self.start_time = time.time()
        self.display_maze()

    def make_move(self, direction):
        y, x = self.current_pos
        
        if direction == 'up':
            new_pos = (y-1, x)
        elif direction == 'down':
            new_pos = (y+1, x)
        elif direction == 'left':
            new_pos = (y, x-1)
        elif direction == 'right':
            new_pos = (y, x+1)
        
        # Check if move is valid
        if (0 <= new_pos[0] < self.size and 
            0 <= new_pos[1] < self.size and 
            self.maze[new_pos] == 0):
            self.current_pos = new_pos
            self.path_taken.append(new_pos)
            self.moves += 1
            return True
            
        return False

    def display_maze(self):
        self.ax.clear()
        
        # Create RGB image
        img = np.stack([self.maze] * 3, axis=-1) * 255
        img[self.start[0], self.start[1]] = [0, 255, 0]  # Green start
        img[self.end[0], self.end[1]] = [255, 0, 0]      # Red end

        for y, x in self.path_taken[1:]:
            img[y, x] = [0, 0, 255]  # Blue path
            img[self.current_pos[0], self.current_pos[1]] = [255, 255, 0]  # Yellow current

        self.ax.imshow(img)
        self.ax.set_title(f'Moves: {self.moves}')

        if self.current_pos == self.end:
            elapsed_time = time.time() - self.start_time
            print("\nMaze Solved!")
            print(f"Moves taken: {self.moves}")
            print(f"Time taken: {elapsed_time:.2f} seconds")
            print(f"Path length: {len(self.path_taken)}")
            manhattan_dist = abs(self.end[0] - self.start[0]) + abs(self.end[1] - self.start[1])
            efficiency = manhattan_dist / len(self.path_taken)
            print(f"Path efficiency: {efficiency:.2f}")

            # Use MazeSolver to compute metrics for each algorithm
            solver = MazeSolver(self.maze, self.start, self.end)
            
            # Track memory usage for each algorithm
            for algo in ["A*", "Greedy", "Uniform"]:
                # Start tracking memory
                tracemalloc.start()
                process = psutil.Process()
                mem_before = process.memory_info().rss / 1024 / 1024  # in MB
                
                # Solve maze and track metrics
                result = solver.solve(algorithm=algo)
                
                # Stop tracking memory
                mem_after = process.memory_info().rss / 1024 / 1024  # in MB
                mem_used = mem_after - mem_before
                
                # Get tracemalloc stats
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                
                print(f"\n{algo} Search Metrics:")
                print(f"  Moves: {result['moves']}")
                print(f"  Path Length: {result['path_length']}")
                print(f"  Time Taken: {result['time']:.2f} seconds")
                print(f"  Efficiency: {result['efficiency']:.2f}")
                
                # Memory Metrics
                print(f"  Memory Usage:")
                print(f"    Process Memory Change: {mem_used:.2f} MB")
                print(f"    Peak Traced Memory: {peak / 1024 / 1024:.2f} MB")

        plt.draw() 
   
    def on_key_press(self, event):
        if event.key in ['up', 'down', 'left', 'right']:
            if self.make_move(event.key):
                self.display_maze()

    def on_close(self, event):
        plt.close('all')

def main():
    maze = InteractiveMaze(size=25, complexity=0.5)  # Adjust complexity as needed
    plt.show(block=True)

if __name__ == "__main__":
    main()